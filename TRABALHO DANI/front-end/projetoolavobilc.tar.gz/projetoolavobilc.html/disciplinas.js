$(document).ready(function(){

    $("#elemento1").click(function(){
        $(".texto1").hide();
        $("#conteudo1").show();

    });
    $("#elemento2").click(function(){
        $(".texto1").hide();
        $("#conteudo2").show();

    });
        $("#elemento3").click(function(){
            $(".texto1").hide();
            $("#conteudo3").show();
    });    
        $("#elemento4").click(function(){
            $(".texto1").hide();
            $("#conteudo4").show();
        });  
    });